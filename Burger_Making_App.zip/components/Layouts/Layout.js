import Aox from "../../hoc/Aox"
import './Layout.css';

const Layout = (props) => {
    return (
        <>
            <header>Header</header>
            <main className='Content'>
                {props.children}
            </main>
        </>
    );
}

export default Layout
