import Aox from "../../../hoc/Aox"
import './Model.css';

const Model = (props) => {
    return (
        <Aox>
            <div className="Modal">
                {props.children}
            </div>
        </Aox>

    )
}

export default Model
